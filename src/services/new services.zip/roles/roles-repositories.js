import pool from '../../database/pool.js';

class RolesRepositories {
  constructor() {
    this.pool = pool;
  }

  async getAllRoles() {
    const query = {
      text: 'SELECT * FROM roles',
    };

    const result = await this.pool.query(query);
    return result.rows;
  }

  async getRoleById(id) {
    const query = {
      text: 'SELECT * FROM roles WHERE id = $1',
      values: [id],
    };

    const result = await this.pool.query(query);
    return result.rows[0];
  }

  async createRole(id, name) {
    const query = {
      text: 'INSERT INTO roles (id, name) VALUES ($1, $2) RETURNING *',
      values: [id, name],
    };

    const result = await this.pool.query(query);
    return result.rows[0];
  }

  async updateRole(id, name) {
    const query = {
      text: 'UPDATE roles SET name = $1 WHERE id = $2 RETURNING *',
      values: [name, id],
    };

    const result = await this.pool.query(query);
    return result.rows[0];
  }

  async deleteRole(id) {
    const query = {
      text: 'DELETE FROM roles WHERE id = $1 AND is_system = false RETURNING *',
      values: [id],
    };

    const result = await this.pool.query(query);
    return result.rows[0];
  }


};

export default RolesRepositories;

